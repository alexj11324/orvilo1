#!/usr/bin/env node
// Finite #780 CSS-equivalence proof. This is not whole #690 or real-device safe-area acceptance.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import vm from 'node:vm';

const packet = path.dirname(fileURLToPath(import.meta.url));
const root = process.env.ORVILO_ROOT || '/workspace/orvilo1';
const output = process.argv[2] || path.join(packet, 'compile-proof');
await mkdir(output, { recursive: true });
const requireRoot = createRequire(path.join(root, 'package.json'));
const ts = requireRoot('typescript');
const postcss = requireRoot('postcss');
const tailwindNode = path.join(root, 'node_modules/.pnpm/@tailwindcss+node@4.3.3/node_modules/@tailwindcss/node');
const tailwindPackage = JSON.parse(await readFile(path.join(root, 'node_modules/tailwindcss/package.json'), 'utf8'));
const compilerPackage = JSON.parse(await readFile(path.join(tailwindNode, 'package.json'), 'utf8'));
assert.equal(compilerPackage.version, tailwindPackage.version, 'Installed Tailwind compiler/package versions differ');
const compilerEntry = path.resolve(tailwindNode, compilerPackage.exports['.'].import);
const { compile } = await import(pathToFileURL(compilerEntry));
const { build } = await import(pathToFileURL(requireRoot.resolve('vite')));
const playwright = await import(pathToFileURL(path.join(root, 'node_modules/.pnpm/playwright@1.63.0/node_modules/playwright/index.mjs')));
const sha = (value) => createHash('sha256').update(value).digest('hex');
const manifest = JSON.parse(await readFile(path.join(packet, 'manifest.json'), 'utf8'));
const actualHead = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim();
const bindings = [];
for (const row of manifest.rows) {
  const delivered = await readFile(path.join(packet, 'after', row.path));
  assert.equal(sha(delivered), row.afterSHA256, `Packet changed: ${row.path}`);
  if (!row.new) {
    const original = await readFile(path.join(packet, 'before', row.path));
    assert.equal(sha(original), row.beforeSHA256, `Original packet changed: ${row.path}`);
    const gitBefore = execFileSync('git', ['show', `${manifest.base}:${row.path}`], { cwd: root });
    assert.equal(sha(gitBefore), row.beforeSHA256, `Baseline Git source differs: ${row.path}`);
  }
  const actual = await readFile(path.join(root, row.path));
  const byteEqual = actual.equals(delivered);
  if (row.path.endsWith('.tsx')) {
    const emit = (data) => ts.transpileModule(data.toString(), {
      compilerOptions: { jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
      fileName: row.path,
    }).outputText;
    assert.equal(emit(actual), emit(delivered), `Root runtime differs from delivered packet: ${row.path}`);
  } else assert.ok(byteEqual, `Root CSS differs from delivered packet: ${row.path}`);
  bindings.push({ path: row.path, actualSHA256: sha(actual), packetSHA256: row.afterSHA256, byteEqual,
    emittedJavaScriptEqual: row.path.endsWith('.tsx') ? true : undefined });
}

const navPath = 'src/routes/(mobile)/_layout/NavBar.module.css';
const categoryPath = 'src/routes/(mobile)/me/settings/features/Category.module.css';
const entry = path.join(packet, 'module-entry.mjs');
await writeFile(entry, `import nav from ${JSON.stringify('./after/' + navPath)};\nimport category from ${JSON.stringify('./after/' + categoryPath)};\nglobalThis.__probeModules = { nav, category };\n`);
// Actual installed Vite's CSS-module pipeline: output CSS and JS exports, no product build or dev server.
const bundle = await build({ root: packet, configFile: false, logLevel: 'error',
  build: { write: false, minify: false, cssMinify: false, rollupOptions: { input: entry } } });
const outputs = (Array.isArray(bundle) ? bundle : [bundle]).flatMap((part) => part.output);
const moduleCSS = outputs.filter((item) => item.type === 'asset' && item.fileName.endsWith('.css')).map((item) => String(item.source)).join('\n');
assert.ok(moduleCSS.length, 'Vite emitted no CSS-module asset');
const jsChunks = outputs.filter((item) => item.type === 'chunk');
assert.equal(jsChunks.length, 1, 'Unexpected module JS split');
const context = {};
vm.runInNewContext(jsChunks[0].code, context, { timeout: 1000 });
const moduleExports = context.__probeModules;
assert.ok(typeof moduleExports?.nav?.container === 'string', 'Missing real NavBar container export');
assert.ok(typeof moduleExports?.category?.groupTitle === 'string', 'Missing real Category groupTitle export');
await writeFile(path.join(output, 'vite-module.css'), moduleCSS);
await writeFile(path.join(output, 'vite-module.js'), jsChunks[0].code);

const cases = [
  { id: 'issueIdentifier', before: 'min-w-[var(--issue-id-width,auto)]', after: 'min-w-(--issue-id-width,auto)', properties: ['minWidth'] },
  { id: 'memoryTimeline30', before: 'w-[30%]', after: 'w-3/10', properties: ['width'], fraction: 3 / 10 },
  { id: 'memoryTimeline66', before: 'w-[66%]', after: 'w-33/50', properties: ['width'], fraction: 33 / 50 },
  { id: 'memoryCard80', before: 'w-[80%]', after: 'w-4/5', properties: ['width'], fraction: 4 / 5 },
  { id: 'memoryCard66', before: 'w-[66%]', after: 'w-33/50', properties: ['width'], fraction: 33 / 50 },
  { id: 'mobileNavSafeArea', before: 'h-[calc(var(--spacing)*12+env(safe-area-inset-bottom))] pbe-[env(safe-area-inset-bottom)]',
    after: 'h-(--mobile-nav-height) pbe-(--mobile-nav-safe-area-bottom)', module: moduleExports.nav.container, properties: ['height', 'paddingBlockEnd'] },
  { id: 'mobileCategoryTracking', before: 'tracking-[calc(var(--spacing)*0.125)]', after: 'tracking-(--mobile-settings-category-tracking)',
    module: moduleExports.category.groupTitle, properties: ['letterSpacing'] },
];
const input = '@import "tailwindcss" source(none);';
const dependencies = new Set();
const compilerOptions = { base: root, onDependency: (file) => dependencies.add(file) };
const beforeCompiler = await compile(input, compilerOptions);
const afterCompiler = await compile(input, compilerOptions);
const beforeCSS = beforeCompiler.build([...new Set(cases.flatMap((item) => item.before.split(' ')))]);
const afterCSS = afterCompiler.build([...new Set(cases.flatMap((item) => item.after.split(' ')))]);
await writeFile(path.join(output, 'tailwind-before.css'), beforeCSS);
await writeFile(path.join(output, 'tailwind-after.css'), afterCSS);
const declarations = (css) => {
  const rows = [];
  postcss.parse(css).walkRules((rule) => {
    if (!rule.selector.startsWith('.')) return;
    const values = [];
    rule.each((node) => { if (node.type === 'decl') values.push({ property: node.prop, value: node.value }); });
    if (values.length) rows.push({ selector: rule.selector, values });
  });
  return rows;
};
const beforeRules = declarations(beforeCSS);
const afterRules = declarations(afterCSS);
assert.ok(beforeRules.some((row) => row.values.some((d) => d.property === 'min-width' && d.value.replace(/\s/g, '') === 'var(--issue-id-width,auto)')), 'Original identifier fallback not emitted');
assert.ok(afterRules.some((row) => row.values.some((d) => d.property === 'min-width' && d.value.replace(/\s/g, '') === 'var(--issue-id-width,auto)')), 'Replacement identifier fallback not emitted');

const electronMain = path.join(output, 'electron-main.cjs');
await writeFile(electronMain, `const { app, BrowserWindow } = require('electron');\napp.whenReady().then(() => { const win = new BrowserWindow({ width: 1200, height: 900, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, webSecurity: true } }); return win.loadURL('data:text/html,<html><body></body></html>'); }).catch((error) => { console.error(error); app.exit(1); });\n`);
const executablePath = process.env.ORVILO_ELECTRON_BIN || '/tmp/orvilo-cloud-tools-new/node_modules/electron/dist/electron';
let app;
let primaryError;
let results = [];
const fatal = [];
let nativeVersion;
let nativeProcess;
let nativePreferences;
try {
  app = await playwright._electron.launch({ chromiumSandbox: true, executablePath, args: [electronMain, `--user-data-dir=${path.join(output, 'electron-profile')}`],
    env: { ...process.env, DISPLAY: process.env.DISPLAY || ':99' }, timeout: 45000 });
  const page = await app.firstWindow();
  nativeVersion = await app.evaluate(({ app }) => ({ electron: process.versions.electron, chrome: process.versions.chrome,
    version: app.getVersion() }));
  const preferences = await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].webContents.getLastWebPreferences());
  nativePreferences = preferences;
  const child = app.process();
  const actualProcArgv = (await readFile(`/proc/${child.pid}/cmdline`, 'utf8')).split('\0').filter(Boolean);
  const mainArgv = await app.evaluate(() => process.argv);
  nativeProcess = { pid: child.pid, actualProcArgv, spawnargs: child.spawnargs, mainArgv };
  for (const args of [actualProcArgv, child.spawnargs, mainArgv]) {
    assert.ok(args.every((arg) => !/no-sandbox|disable-setuid-sandbox/i.test(arg)), 'Sandbox-disabling flag found on actual owned Electron process');
  }
  assert.equal(preferences.webSecurity, true);
  assert.equal(preferences.sandbox, true);
  assert.equal(preferences.contextIsolation, true);
  assert.equal(preferences.nodeIntegration, false);
  page.on('pageerror', (error) => fatal.push(String(error)));
  page.on('console', (message) => { if (message.type() === 'error') fatal.push(message.text()); });
  page.on('requestfailed', (request) => fatal.push(`${request.url()}: ${request.failure()?.errorText}`));
  const htmlEscape = (text) => text.replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;');
  for (const fontSize of [16, 20]) for (const parentWidth of [333, 1000]) for (const issueWidth of [null, '73.5px']) {
    // env34 is a derived CSS formula probe by substitution. It is not an OS/device measurement.
    for (const domain of ['actual-cloud-electron-env0', 'derived-css-safe-area34']) {
      const safeArea = domain === 'derived-css-safe-area34' ? 34 : 0;
      const css = [beforeCSS, afterCSS, moduleCSS].join('\n');
      const scopedCSS = safeArea ? css.replaceAll('env(safe-area-inset-bottom)', '34px') : css;
      let html = `<style>${scopedCSS}\nhtml{font-size:${fontSize}px}body{margin:0} .probe-parent{display:flex;width:${parentWidth}px} .probe-case{display:block;flex:none;box-sizing:border-box;border:0} #native-safe-area{padding-bottom:env(safe-area-inset-bottom);}</style><div id="native-safe-area"></div>`;
      for (const item of cases) {
        const variable = issueWidth === null ? '' : `--issue-id-width:${issueWidth};`;
        html += `<div class="probe-parent" style="${variable}"><div id="${item.id}-before" class="probe-case ${htmlEscape(item.before)}">${item.id}</div></div><div class="probe-parent" style="${variable}"><div id="${item.id}-after" class="probe-case ${htmlEscape(item.after)} ${htmlEscape(item.module || '')}">${item.id}</div></div>`;
      }
      await page.setContent(html);
      const samples = await page.evaluate((rows) => ({
        nativeSafeArea: getComputedStyle(document.querySelector('#native-safe-area')).paddingBottom,
        values: rows.map((item) => {
          const before = getComputedStyle(document.getElementById(`${item.id}-before`));
          const after = getComputedStyle(document.getElementById(`${item.id}-after`));
          return { id: item.id, properties: Object.fromEntries(item.properties.map((property) => [property, { before: before[property], after: after[property] }])) };
        }),
      }), cases.map(({ id, properties }) => ({ id, properties })));
      assert.equal(samples.nativeSafeArea, '0px', 'Cloud native safe-area is not zero: report actual observed environment before proceeding');
      for (const sample of samples.values) {
        for (const [property, values] of Object.entries(sample.properties)) assert.equal(values.after, values.before, `${domain}/${fontSize}/${sample.id}/${property}`);
        const owner = cases.find((item) => item.id === sample.id);
        if (owner.fraction !== undefined) assert.ok(Math.abs(parseFloat(sample.properties.width.after) - parentWidth * owner.fraction) <= 1 / 64, `Fraction drift ${sample.id}`);
        if (sample.id === 'issueIdentifier') assert.equal(sample.properties.minWidth.after, issueWidth || 'auto');
        if (sample.id === 'mobileNavSafeArea') {
          assert.equal(sample.properties.height.after, `${fontSize * 3 + safeArea}px`);
          assert.equal(sample.properties.paddingBlockEnd.after, `${safeArea}px`);
        }
        if (sample.id === 'mobileCategoryTracking') assert.equal(sample.properties.letterSpacing.after, `${fontSize / 32}px`);
        results.push({ domain, fontSize, parentWidth, issueWidth, nativeSafeAreaObserved: samples.nativeSafeArea, ...sample });
      }
    }
  }
  assert.deepEqual(fatal, [], 'Native compiler probe emitted a browser error');
} catch (error) { primaryError = error; }
finally {
  if (app) { try { await app.close(); } catch (error) { if (!primaryError) primaryError = error; } }
}
const report = { status: primaryError ? 'FAIL' : 'PASS', baseline: manifest.base, actualHead, bindings,
  compiler: { tailwind: { name: tailwindPackage.name, version: tailwindPackage.version, package: path.join(root, 'node_modules/tailwindcss/package.json') }, tailwindNode: { name: compilerPackage.name, version: compilerPackage.version, package: path.join(tailwindNode, 'package.json') }, vite: JSON.parse(await readFile(requireRoot.resolve('vite/package.json'), 'utf8')).version,
    moduleExports, candidates: cases, beforeRules, afterRules, dependencies: [...dependencies] }, nativeVersion,
  scope: 'Seven necessary #780 token-gate repairs only; actual native env0 plus clearly separate derived CSS safe-area34 algebra; no whole-goal or real-device env34 claim.',
  nativeProcess, nativePreferences, nativeSandbox: { chromiumSandbox: true, sandbox: true, contextIsolation: true, nodeIntegration: false, webSecurity: true },
  browserWidthQuantization: 'Before/after CSSOM values must be strictly equal. The 1/64px bound is used only to check Chromium layout quantization against the exact unchanged rational width; raw emitted fraction declarations and class candidates are recorded above. No CSS equivalence tolerance or source rounding is used.', comparisons: results.length,
  results, fatal, error: primaryError ? String(primaryError.stack || primaryError) : null };
await writeFile(path.join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, comparisons: results.length, actualHead, report: path.join(output, 'report.json'), error: report.error }));
if (primaryError) throw primaryError;
