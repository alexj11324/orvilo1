const { app, BrowserWindow } = require('electron');
app.whenReady().then(() => { const win = new BrowserWindow({ width: 1200, height: 900, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, webSecurity: true } }); return win.loadURL('data:text/html,<html><body></body></html>'); }).catch((error) => { console.error(error); app.exit(1); });
