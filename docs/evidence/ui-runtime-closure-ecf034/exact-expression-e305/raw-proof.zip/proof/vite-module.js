//#endregion
//#region ../../tmp/orvilo-pr780-seven-ci-repair/module-entry.mjs
globalThis.__probeModules = {
	nav: { container: "_container_1km8g_1" },
	category: { groupTitle: "_groupTitle_1unps_1" }
};
//#endregion
